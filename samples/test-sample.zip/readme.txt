Sample zip for upload and archive tests.
